import time
import os
import sys
import colorama
from termcolor import colored
from time import sleep
from os import system, name
from colorama import init, Fore, Back, Style
import platform
import psutil
import random
import string
import ctypes
from getpass import getpass

# change @testings to ur desired username
 
ctypes.windll.kernel32.SetConsoleTitleW("tiktok bot made by github/discords-exe")

def clear():
  
    # for windows
    if name == 'nt':
        _ = system('cls')
  
    # for mac and linux(here, os.name is 'posix')
    else:
        _ = system('clear')
clear()
time.sleep(0.03)
print("")
time.sleep(0.03)
print(colored("              _   _ _    _        _             ","magenta"))
time.sleep(0.03)
print(colored("             | | (_) |  | |      | |            ","magenta"))
time.sleep(0.03)
print(colored("             | |_ _| | _| |_ ___ | | __         ","magenta"))
time.sleep(0.03)
print(colored("             | __| | |/ / __/ _ \| |/ /         ","magenta"))
time.sleep(0.03)
print(colored("             | |_| |   <| || (_) |   <         ","magenta"))
time.sleep(0.03)
print(colored("              \__|_|_|\_\\__ \___/|_|\_\       ","magenta"))
time.sleep(0.03)
print("")
time.sleep(0.03)
Fore.YELLOW 
username = input("Enter Desired Username   : ")

ctypes.windll.kernel32.SetConsoleTitleW("tiktok bot made by github/discords-exe. spamming")

x = 0
for i in range (375):
    x=x + 1
    print(Fore.RED + "> Attempting to claim @" + (username) + Fore.MAGENTA + " attempt -", x)
    time.sleep(0.03)

ctypes.windll.kernel32.SetConsoleTitleW("tiktok bot made by github/discords-exe. claimed")

print(Fore.GREEN + "> Claimed @" + (username))

time.sleep(0.3)

time.sleep(0.5)

closing = Fore.YElLOW + "tiktok 2022 ©"
for char in closing:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.07)

time.sleep(1)
print(Fore.RESET)